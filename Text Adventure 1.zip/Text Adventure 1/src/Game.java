import java.util.Scanner;
public class Game 
{
	public static void main (String [] args)
	{
		String a = "You see a tumultuous dark sea, with a faint red bridge in the distance\nWith a bitter sense of certainty, you realize that you are on the very island which destroyed the hope of many people before you\nYou realize that you are on Alcatraz Island\n";
		String b = "You try a bit longer and it breaks\nYou walk outside of your cell and look around you\n";
		System.out.println("You wake up in a dark room with a barred window and a door");
		if (prompt("Do you want to check the door?"))
		{
			System.out.println("You walk over to the door and it's locked");
			if (prompt("Do you try to open it?"))
			{
				System.out.println("You struggle with it, but feel it start to weaken");
				if (prompt("Do you keep trying?"))
				{
					System.out.println(b);
					if (prompt("Suddenly you hear voices, do you want to: yes, run back into your cell or no, run  away from the voices?"));
				}
				else 
				{
					System.out.println("you decide to try the window");
					if (prompt("do you want to look outside?"))
					{
						System.out.println(a);
						if (prompt("do you want to check the door again?"))
						{
							System.out.println("You walk over to the door and it's locked");
						}
						if (prompt("Do you try to open it?"))
						{
							System.out.println("You struggle with it, but feel it start to weaken");
							if (prompt("Do you keep trying?"))
							{
								System.out.println(b);
								if (prompt("Suddenly you hear voices, do you want to: yes, run back into your cell or no, run  away from the voices?"));
								System.out.println("You run as fast as you can with the sounds of their footsteps slowly fading behind you");
								System.out.println("You suddenly find yourself at crossroads with an option to your left, in front of you, and your right");
								if (prompt("Do you want to go: right, into the shower;forwards, into the kitchen; right, into the messhall"));
							}
					}
				}
			}
			}
			else
			{
				System.out.println("you decide to try the window");
				if (prompt("do you want to look outside?"));
				{
					System.out.println(a);
					if (prompt("do you want to check the door again?"));
				}
				{
					System.out.println("You struggle with it, but feel it start to weaken");
				if (prompt("Do you keep trying?"));
				{
					System.out.println(b);
					if (prompt("Suddenly you hear voices, do you want to: yes, run back into your cell or no, run  away from the voices?"));
					{
						System.out.println("You run as fast as you can with the sounds of their footsteps slowly fading behind you");
						System.out.println("You suddenly find yourself at crossroads with an option to your left, in front of you, and your right");
						if (prompt("Do you want to go: right, into the shower;forwards, into the kitchen; right, into the messhall"));
					}
				}
				}
			}
		}
		else
		{
			System.out.println("You walk over to the window and look outside");
			System.out.println(a);
			if (prompt("do you want to check the door again?")) 
		{
			System.out.println("You struggle with it, but feel it start to weaken");
			if (prompt("Do you keep trying?"))
			{
				System.out.println(b);
				if (prompt("Suddenly you hear voices, do you want to: yes, run back into your cell or no, run  away from the voices?"));
				{
					System.out.println("You run back inside and hold your breath");
					System.out.println("You wait for what feels like an eternity until two shots ring out in the silence");
					System.out.println("You fall to your knees and the world turns to  darkness");
				} 
			}
			
			} else {
				System.out.println("You run as fast as you can with the sounds of their footsteps slowly fading behind you");
				System.out.println("You suddenly find yourself at crossroads with an option to your left, in front of you, and your right");
				if (prompt("Do you want to go: right, into the shower;forwards, into the kitchen; right, into the messhall"));
			}
		}
	}
	public static boolean prompt(String q)
	{
		Scanner sc = new Scanner(System.in);
		String a;
		System.out.println(q);
		a = sc.nextLine();
		if (a.charAt(0) == 'y' || a.charAt(0) == 'Y')
		{
			return true;
		}
		return false;
	}
}
